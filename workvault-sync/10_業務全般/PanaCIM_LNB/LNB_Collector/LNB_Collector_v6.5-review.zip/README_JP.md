# LNB Collector v6.4.3-review — 使用説明

## 位置づけ・重要警告
今回新規に組み直した**レビュー用別版**です。旧 `5-review` を最新版と称するものではありません。コードはレビュー対象であり、PowerShell 5.1 Windows実機・組織USB・対象共有/端末での実行試験はしていません。配布側署名はありません。未検証のまま業務PCで使わず、担当者レビューと許可を先行してください。

ImportExcel **7.8.10**が必須です。承認された一式をUSB上の`tools\ImportExcel`へ別途用意する必要があります。このZIPには含まれず、コードは取得/インストールしません。存在、manifest版、コマンドの実ロード元、およびモジュールツリー内reparse pointを確認し、依存不備時は収集前に停止します。

## 対象/起動
- Windows PowerShell 5.1 Desktop。PowerShell 7、管理者昇格、ExecutionPolicy変更、Bypass、Unblock、モジュール自動download/installは行いません。
- 登録はUSB直下に配置後に `Register_USB.cmd` を一度だけ実行。BusType=USB、ハードウェアディスクSerial、ドライブのVolumeSerial、root markerを照合します。ドライブ文字は固定しません。登録時の対話確認が必須で、既存markerは上書きしません。
- `PREPARE_USB.cmd`は登録/依存モジュールの確認だけを行い、収集しません。
- `TEST_LNB.cmd` は自己テストのみ（共有出力や収集は行わない）。通常起動時にも合成テストと `Parser.ParseFile` を実施します。
- `Run_LNB.cmd` を通常権限で起動。L1/L2/L3を指定し、明示確認で`YES`を入力するまでデータ収集しません。

USB固有のシリアルがOS/USBブリッジにより提供されない環境は、推測/fallbackせず停止します。USB識別は暗号学的認証ではありません。登録マーカー/GUIDは暗号署名ではなく、改ざん・偽装・クローンを防ぐ認証機構ではありません。

## 出力場所・安全な作成
同一USB上の `data\LNB_調査\<L1|L2|L3>_<PC名>_<時刻>_<GUID>\`。ドライブ文字はUSB識別に従って可変です。既存フォルダー再利用や別保存先へのfallbackはしません。フォルダー新規作成は親から一段ずつ行い、作成前の祖先を含む各要素についてreparse pointを検査し、作成後にも再検査。書込時もUSB identityと出力パスのreparseを再確認します。書込失敗なら処理を止め、部分status/CSV/JSONを残せる範囲で残し、`COMPLETE.txt`は生成しません。

### 生成ファイル
`LNB_Collector.xlsx` 1冊（10収集シート `computer`, `os`, `cpu`, `memory`, `disks`, `printers`, `processes`, `office`, `excel_recent`, `windows_recent` と `Metadata`, `SelfTest`, `Status` の計13シート）、同じ10種のCSV/JSON、`selftest.json`, `status.json`, `summary.json`, 最後に`COMPLETE.txt`。CSV/JSON/XLSXはいずれも値を安全化し、CSV式注入対策を施す。空のCSV・DataTableも固定列ヘッダーを保持する。ExcelはImportExcel `Export-Excel -NoNumberConversion '*'`で生成し、`Open-ExcelPackage`で開き直して13シートの名称/列/行数を検査後にのみ完了扱い。

## 収集範囲と制限
- OS/コンピューター/CPU/物理メモリ/固定ディスク/プリンターはlocal CIM (各コマンド`OperationTimeoutSec=10`)。CIM全体/OS providerの時間保証ではありません。
- プロセスは名前/PIDのみ。最大500件、501件目を先読みし上限警告。
- Excel MRUは利用者のHKCU、Office 14/15/16のExcel `File MRU` と `User MRU` 配下最大64子キーの`File MRU`、最大500候補。Excel MRU値のパス文字列のみで、対象ファイルへのアクセス/存在確認/内容読込はしません。除外・読取失敗・上限を状態に記録。**MRUは実利用の証明でも実利用者の特定でもなく、実使用日時を示しません。**
- Windows Recentは固定ローカルAPPDATA配下のRecentディレクトリから過去30日の`.lnk`名/ショートカット更新日時のみ最大500件。Recentに至る親のreparseを検査し、見つかればスキップ。リンクtarget・引数は解決しません。更新日時は実際の文書使用日時と断定できません。
- Officeは2箇所のClick-to-Runレジストリの製品ID/バージョン/プラットフォームのメタデータのみ。全Office版の網羅ではありません。
- CIMやprocessなどの取得行は最大500行に制限。部分出力/Skipped/Failed/Truncatedは`Status`等で確認。NoDataは未使用や非導入の証明ではありません。

ブラウザ履歴、Cookie、資格情報、文書内容、全ドライブ走査、プロセス引数、ウィンドウタイトル、ショートカットのリンク先、Excel COMは対象外。ネットワーク/サービス/Windows providerの遅延があるため全実行時間上限は保証しません。

## 終了
- `0`: 完了、警告状態なし。
- `10`: 完了、Failed/Partial/Truncated/Skipped等の警告を含む。
- `2`: 利用者取消/不正ライン。
- `3`: self-test/parser失敗またはTestOnly失敗。
- `5`: 実行/出力のfatal失敗。その他は未完了扱い。

登録マーカーに含むGUID/Serialは暗号認証ではありません。アカウント名・文書パス等は機微情報になり得ます。保存先ACL/保存期間/配布範囲を組織で定め、出力を適切に扱ってください。

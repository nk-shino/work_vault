# 配布・レビュー・現場実施 セキュリティチェックリスト

## パッケージ/供給
- [ ] `MANIFEST_SHA256.txt`を使い、展開後の各掲載ファイルのSHA-256を照合（マニフェスト自身は署名済みではない。真正性は別経路で確認）。
- [ ] v6.4.3-reviewであることを確認。旧5-review原稿や過去SAS URLを最新版と誤認しない。
- [ ] ソースコードを承認者がレビュー。組織のコード署名/署名確認手順を実行。
- [ ] 組織承認済ImportExcel 7.8.10全体とEPPlus依存を別途配置し、出所/バージョン/ライセンス/署名を検証。`tools\ImportExcel`以下にreparse pointなし。非承認のmodule取得禁止。
- [ ] 各PCにWindows PowerShell 5.1 Desktop、USB Storage cmdlets、USB bus/disk/volume identifiersが実際に利用可能か限定環境で検証。

## 設置・実行
- [ ] USBの利用許可、保存先、収集アカウント、ライン、日時、対象PC、作業影響、関係者通知を承認。
- [ ] USB直下にスクリプトを配置。register時にディスク/volume serialを目視照合。登録markerは上書きしない。
- [ ] `TEST_LNB.cmd`の実機結果を確認。テストは本番アクセス/収集の成立を保証しない。
- [ ] 通常権限、ExecutionPolicy回避なし、昇格なしで実行。確認表示と `YES` を現場担当者が確認。
- [ ] USBを物理的に安定保持。空き容量、ACL、書込み保護、暗号化/持出しルールを確認。
- [ ] `COMPLETE.txt`と終了コードだけでなく、13-sheet workbookを開いて列/データ/状態を確認。マーカー不在なら未完了として扱う。
- [ ] 機微なパス・利用者名を共有する前に必要最小限化。保管・消去期限を適用。

## 仕様・残留リスク
- [ ] Serial/GUID root markerは暗号認証ではなく、複製/改ざんの完全防止ではない。
- [ ] 10秒CIM OperationTimeoutは全体処理のhard timeoutでない。
- [ ] Windows実機構文解析/実行/Excel workbook生成/各種故障注入は配布側未実施。
- [ ] Recent / MRU は使用事実/実利用者/実使用時間の証拠ではない。
- [ ] CSV数式/パス秘匿フィルターは全機微データを検出する保証なし。
- [ ] 手動ダウンロード、インストール、ExecutionPolicy変更、Unblock、管理者昇格を要求しない。

@echo off
setlocal
powershell.exe -NoProfile -File "%~dp0Collect_LNB.ps1" -PrepareOnly
set "RC=%ERRORLEVEL%"
echo Prepare exit code: %RC%
pause
exit /b %RC%

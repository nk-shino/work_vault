@echo off
setlocal
powershell.exe -NoProfile -File "%~dp0Collect_LNB.ps1"
set "RC=%ERRORLEVEL%"
echo.
echo Exit code: %RC% -- 0=complete, 10=complete with warnings, other=not complete
pause
exit /b %RC%

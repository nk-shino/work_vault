@echo off
setlocal
powershell.exe -NoProfile -File "%~dp0Collect_LNB.ps1" -TestOnly
set "RC=%ERRORLEVEL%"
echo Exit code: %RC%
pause
exit /b %RC%

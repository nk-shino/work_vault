# 検証報告 — LNB Collector v6.5-review

## 結論
v6.4.3-review のソースレビューで指摘した6点を改修し、Windows PowerShell 5.1 実機(作業用PC、環境A)での自己テスト・構文検証を実施し全件PASSを確認した。USB識別・ImportExcel依存・実収集・XLSX作成の統合試験(環境B/C)は**未実施**であり、結合テスト計画書(同梱)の環境B/Cでの実施が配布の前提である。版はレビュー版であり本番承認ではない。

## v6.4.3-review からの改修内容(6点)

| # | 指摘 | 改修 |
| --- | --- | --- |
| 1 | `Safe` の式注入対策正規表現 `[=+@-]` が文字クラス内で範囲解釈される恐れ(`@`から`-`) | `[=+@\-]` にエスケープ修正 |
| 2 | 出力ファイル書込後の読み戻し検証がなく、書込失敗(USB抜去等)を検知できない | `WriteAllTextVerified` を新設。status.json/各CSV/JSON/COMPLETE.txt に適用し、書込直後に読み戻し失敗なら throw |
| 3 | XLSX 出力先が USB 上であることの明示確認がなかった | `AssertOnUsb` を新設し CreateWorkbook 冒頭で確認 |
| 4 | 出力ディレクトリ作成後の reparse point 再検査が EnsureSafeDir 内のみ(TOCTOU の窓) | 作成直後に `Get-Item -Force` で再検査を追加 |
| 5 | XLSX 作成中に USB 抜去した場合、Metadata シートの Finished/Completion が未確定値になる | XLSX 用に `$metaCopy`(pscustomobject)を作成し、確定値を反映 |
| 6 | fatal 時の catch 内で WriteState が失敗すると fatal 記録自体が失われる可能性 | fatal 記録の try-catch を二重化し、記録失敗を許容して exit 5 を保証 |

版番号は `6.5-review` に更新(マーカー RootMarker 含む)。禁止ワード(ExecutionPolicy変更/Bypass/Unblock/自動download/install/Excel COM/昇格)の追加はなし。

## 実施済み試験(環境A: 作業用PC、2026-10-13)

- `Parser.ParseFile` による構文検証: **エラー 0件**
- `TEST_LNB.cmd` 相当(`-TestOnly`)の実行: **14ケース全PASS、exit 0**
  - Local doc / UNC doc / URL rejected / device rejected / query rejected / suspicious name rejected / ADS rejected / extension rejected / MRU marker parse / MRU filename brackets / CSV formula defense / CSV header on empty / CSV escaped value / PowerShell parser
- 改修#1の効果は「CSV formula defense」がPASSしていることで確認(`Safe "`t=1+1"` → `"' =1+1"`)
- MANIFEST_SHA256.txt を全12ファイルで再生成し、読み戻し照合 12/12 一致
- 配布ZIP(13エントリ)を作成し、サイズ照合とCRC構造を確認。日本語ファイル名(結合テスト計画書.md)はUTF-8で格納

## 未実施(環境B/C での必須試験 — 結合テスト計画書 §6-7 参照)

- USB bus type/serial/volume serial/drive letter変化/marker上書き拒否/異なるUSB拒否(環境B/C)
- ImportExcel承認版・manifest mismatch・未配置・module tree reparse拒否・command origin/version(環境B)
- 実収集→XLSX 13シート作成/再open検証/行数照合(環境C)
- 出力パス内junction設置での停止、書込失敗時のCOMPLETE不在(環境C)
- MRU read errors/上限501件、Recent祖先junction、CIM timeout/失敗時のStatus記録(環境C)
- 承認済みテスト環境での通常アカウント実行、出力機微性レビュー(環境C)

環境B/Cは結合テスト計画書のスケジュール(§9)に従い、レビュー承認後に実施すること。故障注入を本番環境で無断実施しない。

#!/bin/sh
#chkconfig: 2345 66 20
#description: COMODO Mail Gateway

#For SUSE
### BEGIN INIT INFO
# Provides:          cmgdaemon
# Required-Start:    
# Required-Stop:     
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: COMODO cmgdaemon service
### END INIT INFO

#############################################################################
#            Copyright (C) 2011 COMODO, Inc.                                   #
#                   All Rights Reserved                                         #
#                                                                               #
# load_cmgdaemon : This starts and stops the COMODO Mail Gateway for MTAs  #
# process-name: cmgdaemon                                                       #
#                                                                               #
#############################################################################

CHGDIR=/opt/COMODO
PROG_NAME=/opt/COMODO/cmgdaemon
CMDRET=0

# check whether the executable file is present or not
[ -f "$PROG_NAME" ] || exit 1

user_id=`id -u`
if [ $user_id -ne 0 ]
then
    echo "ERROR:To run this script make sure you have Super User (root) permission."  
    exit
fi

FOUND=0
for TOS in Red Fedora SUSE Debian Ubuntu SliTaz Mint
do
 if [ $FOUND -eq 0 ]
 then
    cat /etc/issue | grep $TOS > /dev/null 2>&1
        if [ $? -eq 0 ]
        then
            OS=$TOS
            FOUND=1
        fi
 fi
done

#echo "OS is $OS"

case $OS in
SUSE) 
  . /etc/rc.status
  ;;
Debian|Ubuntu|Mint)
  . /lib/lsb/init-functions
  ;;
SliTaz)
  ;;
*)
  . /etc/init.d/functions
  ;;
esac


#
# Start Daemon
#

start()
{
   chmod +x $PROG_NAME > /dev/null 2>&1

   sh $0 status | grep "The cmgdaemon is running" > /dev/null 2>&1
   if [ $? -eq 0 ]
   then
        echo "The cmgdaemon is already running!"
   else
        echo -n $"Starting cmgdaemon: "

    case $OS in
    SUSE) 
        export LD_LIBRARY_PATH=$CHGDIR
        startproc $PROG_NAME 
        rc_status -v
        ;;
    Debian|Ubuntu|Mint)
        #chmod +x /etc/init.d/load_daemon.sh
        #cd /etc/init.d
        #update-rc.d load_daemon.sh defaults > /dev/null 2>&1
        start-stop-daemon --start --chdir $CHGDIR --exec $PROG_NAME
        ;;
    SliTaz)
        cd $CHGDIR
        $PROG_NAME
        ;;
    *)
        cd $CHGDIR
        daemon $PROG_NAME
        ;;
    esac 
       
    CMDRET=$?
    if [ $CMDRET -eq 0 ]
    then
        echo "The cmgdaemon started successfully!"  
    else
        echo "The cmgdaemon failed to start!" 
    fi      
   fi
}

#
# Stop Daemon
#
stop()
{
   sh $0 status | grep not > /dev/null 2>&1
   if [ $? -eq 0 ]
   then
        echo "The cmgdaemon is not running!"
   else
        echo -n $"Stopping cmgdaemon: "

    case $OS in
    SUSE) 
        killproc $PROG_NAME
        rc_status -v
        ;;
    Debian|Ubuntu|Mint)
        pkill -KILL cmgdaemon >/dev/null 2>&1
        ;;
    SliTaz)
	PID=$(ps -el | grep cmgdaemon | sed '/grep/d' | sed '/load_cmgdaemon.sh/d' | awk '{print $1}')      
        while [ "0$PID" != "0" ]; do
	    kill $PID >/dev/null 2>&1
            sleep 1
	    PID=$(ps -el | grep cmgdaemon | sed '/grep/d' | sed '/load_cmgdaemon.sh/d' | awk '{print $1}')	
        done
        ;;
    *)
        killproc ./cmgdaemon
        ;;
    esac        
 
    CMDRET=$?
    if [ $CMDRET -eq 0 ]
    then
        echo "The cmgdaemon stopped successfully!"  
    else
        echo "The cmgdaemon failed to stop!" 
    fi      
   fi
}

#
# Status function
#
status() {
    PID=$(ps -el | grep cmgdaemon | sed '/grep/d' | sed '/load_cmgdaemon.sh/d' | awk '{print $1}')
    if [ "0$PID" != "0" ]
    then 
        echo "\"The cmgdaemon is running!"\"
    else
      echo "\"The cmgdaemon is not running!\""
    fi
}

#
# Restart Daemon
#
restart(){
    stop    
    start
}


#
#  Start Here
#
case "$1" in
    start) start ;;
    stop)    stop    ;;
    status) status ;;
    restart)    restart    ;;
    *) echo $"Usage: $0 {start|stop|status|restart}" ;;
esac


case $OS in
SUSE) 
  rc_exit
  ;;
*)
  ;;
esac

exit $CMDRET


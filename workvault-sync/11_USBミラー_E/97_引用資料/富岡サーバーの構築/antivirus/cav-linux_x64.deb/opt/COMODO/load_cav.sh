#!/bin/sh

#############################################################################
#            Copyright (C) 2011 COMODO, Inc.                                   #
#                   All Rights Reserved                                         #
#                                                                               #
# load_cav : This starts and stops the COMODO Antivirus UI  #
# process-name: cav                                                       #
#                                                                               #
#############################################################################

CHGDIR=/opt/COMODO
PROG_NAME=/opt/COMODO/cav
CMDRET=0

# check whether the executable file is present or not
[ -f "$PROG_NAME" ] || exit 1

FOUND=0
for TOS in Red Fedora SUSE Debian Ubuntu SliTaz Mint
do
 if [ $FOUND -eq 0 ]
 then
    cat /etc/issue | grep $TOS > /dev/null 2>&1
        if [ $? -eq 0 ]
        then
            OS=$TOS
            FOUND=1
        fi
 fi
done

#echo "OS is $OS"

case $OS in
SUSE) 
  . /etc/rc.status
  ;;
Debian|Ubuntu|Mint)
  . /lib/lsb/init-functions
  ;;
SliTaz)
  ;;
*)
  . /etc/init.d/functions
  ;;
esac


#
# Start Daemon
#

start()
{
  mkdir -p /var/run/comodo > /dev/null 2>&1
  chmod 775 /var/run/comodo > /dev/null 2>&1
  chmod +x $PROG_NAME > /dev/null 2>&1

   sh $0 status | grep "is running" > /dev/null 2>&1
   if [ $? -eq 0 ]
   then
        echo "The cav is already running!"
   else
        echo -n $"Starting cav: "

    case $OS in
    SUSE) 
        export LD_LIBRARY_PATH=$CHGDIR
        startproc $PROG_NAME 
        rc_status -v
        ;;
    Debian|Ubuntu|Mint)
        /sbin/start-stop-daemon --start --chdir $CHGDIR --exec $PROG_NAME
        ;;
    SliTaz)
        cd $CHGDIR
        $PROG_NAME
        ;;
    *)
        cd $CHGDIR
        daemon $PROG_NAME
        ;;
    esac        
    CMDRET=$?
    if [ $CMDRET -eq 0 ]
    then
        echo "The cav started successfully!"  
    else
        echo "The cav failed to start!" 
    fi      
   fi
}

login()
{
   sh $0 status | grep "is running" > /dev/null 2>&1
   if [ $? -eq 0 ]
   then
        echo "The cav is already running!"
   else
        echo -n $"Starting cav: "

        cd /opt/COMODO/
        ./cav -d       
    CMDRET=$?
    if [ $CMDRET -eq 0 ]
    then
        echo "The cav started successfully!"  
    else
        echo "The cav failed to start!" 
    fi                  
   fi
}

#
# Stop Daemon
#
stop()
{
   sh $0 status | grep not > /dev/null 2>&1
   if [ $? -eq 0 ]
   then
        echo "The cav is not running!"
   else
        echo -n $"Stopping cav: "

    case $OS in
    SUSE) 
        killproc $PROG_NAME
        rc_status -v
        ;;
    Debian|Ubuntu|Mint)
        pkill -KILL -x cav >/dev/null 2>&1
        ;;
    SliTaz)
	PID=$(ps -el | grep cav | sed '/grep/d' | sed '/load_cav.sh/d' | awk '{print $1}')    
        while [ "0$PID" != "0" ]; do
            kill $PID >/dev/null 2>&1
            sleep 1
	    PID=$(ps -el | grep cav | sed '/grep/d' | sed '/load_cav.sh/d' | awk '{print $1}')	
        done
        ;;
    *)
        killproc ./cav
        ;;
    esac        
    CMDRET=$?
    if [ $CMDRET -eq 0 ]
    then
        echo "The cav stopped successfully!"   
    else
        echo "The cav failed to stop!" 
    fi                  
   fi
}

#
# Status function
#
status() {
    PID=$(ps -el | grep cav | sed '/grep/d' | sed '/load_cav.sh/d' | awk '{print $1}')
    if [ "0$PID" != "0" ]
    then 
        echo "\"The cav is running!"\"
    else
      echo "\"The cav is not running!\""
    fi
}

#
# Restart Daemon
#
restart(){
    stop    
    start
}


#
#  Start Here
#
case "$1" in
    start) start ;;
    login) login ;;
    stop)    stop    ;;
    status) status ;;
    restart)    restart    ;;
    *) echo $"Usage: $0 {start|stop|status|restart}" ;;
esac


case $OS in
SUSE) 
  rc_exit
  ;;
*)
  ;;
esac

if [ $CMDRET -eq 0 ]
then
    exit $CMDRET;
else
    echo "You need logout and login again to start the main UI.";
    exit 0;
fi


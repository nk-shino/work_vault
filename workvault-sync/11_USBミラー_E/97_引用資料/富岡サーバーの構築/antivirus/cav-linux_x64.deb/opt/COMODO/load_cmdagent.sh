#!/bin/sh
#chkconfig: 2345 66 20
#description: COMODO Antivirus Service

#For SUSE
### BEGIN INIT INFO
# Provides:          cmdagent
# Required-Start:
# Required-Stop: 
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: COMODO cmdagent service
### END INIT INFO

#############################################################################
#            Copyright (C) 2011 COMODO, Inc.                                   #
#                   All Rights Reserved                                         #
#                                                                               #
# load_cmdagent : This starts and stops the COMODO Antivirus Service  #
# process-name: cmdagent                                                       #
#                                                                               #
#############################################################################

CHGDIR=/opt/COMODO
PROG_NAME=/opt/COMODO/cmdagent
CMDRET=0

# check whether the executable file is present or not
[ -f "$PROG_NAME" ] || exit 1

user_id=`id -u`
if [ $user_id -ne 0 ]
then
	echo "ERROR:To run this script make sure you have Super User (root) permission."  
	exit
fi

FOUND=0
for TOS in Red Fedora SUSE Debian Ubuntu SliTaz Mint
do
	if [ $FOUND -eq 0 ]
	then
		cat /etc/issue | grep $TOS > /dev/null 2>&1
		if [ $? -eq 0 ]
		then
			OS=$TOS
			FOUND=1
		fi
	fi
done

#echo "OS is $OS"

case $OS in
SUSE) 
	. /etc/rc.status
	;;
Debian|Ubuntu|Mint)
	. /lib/lsb/init-functions
	;;
SliTaz)
	;;
*)
	. /etc/init.d/functions
	;;
esac


#
# Start Daemon
#

start()
{
	chmod +x $PROG_NAME > /dev/null 2>&1
	sh $0 status | grep "cmdagent is running" > /dev/null 2>&1
	if [ $? -eq 0 ]
	then
		echo "The cmdagent is already running!"
	else
		echo -n $"Starting cmdagent: "

		case $OS in
		SUSE) 
			export LD_LIBRARY_PATH=$CHGDIR
			startproc $PROG_NAME 
			rc_status -v
			;;
		Debian|Ubuntu|Mint)
			start-stop-daemon --start --chdir $CHGDIR --exec $PROG_NAME
			;;
		SliTaz)
			cd $CHGDIR	
			$PROG_NAME
			;;
		*)
			cd $CHGDIR
			daemon $PROG_NAME
			;;
		esac 
       
		CMDRET=$?
		if [ $CMDRET -eq 0 ]
		then
			echo "The cmdagent started successfully!"  
		else
			echo "The cmdagent failed to start!" 
		fi
	fi
}

#
# Stop Daemon
#
stop()
{
	sh $0 status | grep not > /dev/null 2>&1
	if [ $? -eq 0 ]
	then
		echo "The cmdagent is not running!"
	else
		echo -n $"Stopping cmdagent: "

		case $OS in
		SUSE) 
			killproc $PROG_NAME
			rc_status -v
			;;
		Debian|Ubuntu|Mint)
			pkill -KILL cmdagent >/dev/null 2>&1
			;;
		SliTaz)
			PID=$(ps -el | grep cmdagent | sed '/grep/d' | sed '/load_cmdagent.sh/d' | awk '{print $1}')      
			while [ "0$PID" != "0" ]; do
				kill $PID >/dev/null 2>&1
				sleep 1
				PID=$(ps -el | grep cmdagent | sed '/grep/d' | sed '/load_cmdagent.sh/d' | awk '{print $1}')
			done
			;;
		*)
			killproc ./cmdagent
			;;
		esac        
 		CMDRET=$?
		if [ $CMDRET -eq 0 ]
		then
			echo "The cmdagent stopped successfully!"  
		else
			echo "The cmdagent failed to stop!" 
		fi
	fi
}

#
# Status function
#
status() {
	PID=$(ps -el | grep cmdagent | sed '/grep/d' | sed '/load_cmdagent.sh/d' | awk '{print $1}')
	if [ "0$PID" != "0" ]
	then 
		echo "\"The cmdagent is running!"\"
	else
		echo "\"The cmdagent is not running!\""
	fi
}

#
# Restart Daemon
#
restart(){
	stop
	sleep 2    
	start
}


#
#  Start Here
#
case "$1" in
	start)
		start 
		;;
	stop)
		stop
		;;
	status)
		status
		;;
	restart)
		restart
		;;
	*)
		echo $"Usage: $0 {start|stop|status|restart}"
		;;
esac

case $OS in
SUSE) 
	rc_exit
	;;
*)
	;;
esac

exit $CMDRET


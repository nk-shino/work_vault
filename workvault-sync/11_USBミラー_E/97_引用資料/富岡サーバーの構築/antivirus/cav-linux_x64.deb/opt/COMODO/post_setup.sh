#!/bin/bash

if [ $(id -u) != "0" ]; then
    echo -e "Please run this script with administrator privileges.\n"
    exit 1
fi

echo -e "\n\033[1mCOMODO Antivirus for Linux 1.1\033[0m\n"
echo -e "\n\033[1mEnd User License Agreement\033[0m\n"
echo -e "\nPlease review the end user license agreement.\n"
echo -e "\nPress Enter to display it.\n"
read DISPLIC
cat /opt/COMODO/doc/eula_free.txt | more

ACCEPT=NO
echo -n "Do you agree with this license?[Y/n]: "
while true; do
    read ANSWER
    if [ -z $ANSWER ]; then
        ACCEPT="YES"
        break;
    fi
    case $ANSWER in
    y|Y|yes|YES) 
        ACCEPT="YES"
        echo
        break
        ;;
    n|N|no|NO)
        ACCEPT="NO"
        echo
        break
        ;;
    *) 
        echo -n "Agree with this license?[Y/n]: "
        continue
        ;;
    esac
    break
done    

if [ "$ACCEPT" = "NO" ]; then
    exit 1
fi

# Get the serial number of the hard disk device
if test -e /dev/hda; then
    HDD_SERIAL_NO=$(/sbin/hdparm -I /dev/hda | grep "Serial Number" | awk '{print $3}')
elif test -e /dev/sda; then
    HDD_SERIAL_NO=$(/sbin/hdparm -I /dev/sda | grep "Serial Number" | awk '{print $3}')
else
    HDD_SERIAL_NO=$(uuidgen -r)
fi

# Compute the md5 digest of the serial number of HDD
COMPUTER_ID=$(echo "$HDD_SERIAL_NO" | md5sum | awk '{print $1}')
PRODUCT_VERSION=$(cat /opt/COMODO/cavver.dat)

sed -i "s/\(<ComputerID>\)\(.*\)\(<\/ComputerID>\)/\1${COMPUTER_ID}\3/" /opt/COMODO/etc/COMODO.xml

echo -e "\n\033[1mFree Registration\033[0m\n"
echo -e "\nReceive the latest COMODO products news, updates and offers \nCOMODO will NOT share your information with any third parties."

while true; do
    echo -n "Please input your email address(optional): "
    read EMAIL
    if [ -z "$EMAIL" ]; then
        break
    else
        break
    fi
done
echo "email:${EMAIL}" > /opt/COMODO/email.txt 2>/dev/null

OS_LANG=$(locale | grep LANG= | sed 's/LANG=//' | sed 's/\..*//')
OS_LANG_ID=1033
case $OS_LANG in 
    "pt_BR" ) OS_LANG_ID=1046;;
    "bg_BG" ) OS_LANG_ID=1026;;
    "zh_CN" ) OS_LANG_ID=2052;;
    "cs_CZ" ) OS_LANG_ID=1029;;
    "nl_NL" ) OS_LANG_ID=1043;;
    "en_US" ) OS_LANG_ID=1033;;
    "et_EE" ) OS_LANG_ID=1061;;
    "fr_FR" ) OS_LANG_ID=1036;;
    "de_DE" ) OS_LANG_ID=1031;;
    "hu_HU" ) OS_LANG_ID=1038;;
    "it_IT" ) OS_LANG_ID=1040;;
    "pl_PL" ) OS_LANG_ID=1045;;
    "pt_PT" ) OS_LANG_ID=2070;;
    "ru_RU" ) OS_LANG_ID=1049;;
    "sk_SK" ) OS_LANG_ID=1051;;
    "es_ES" ) OS_LANG_ID=1034;;
    "sv_SE" ) OS_LANG_ID=1053;;
    "tr_TR" ) OS_LANG_ID=1055;;
    "uk_UA" ) OS_LANG_ID=1058;;
    "af_ZA" ) OS_LANG_ID=1078;;
    "sq_AL" ) OS_LANG_ID=1052;;
    "ar_DZ" ) OS_LANG_ID=5121;;
    "ar_BH" ) OS_LANG_ID=15361;;
    "ar_EG" ) OS_LANG_ID=3073;;
    "ar_IQ" ) OS_LANG_ID=2049;;
    "ar_JO" ) OS_LANG_ID=11265;;
    "ar_KW" ) OS_LANG_ID=13313;;
    "ar_LB" ) OS_LANG_ID=12289;;
    "ar_LY" ) OS_LANG_ID=4097;;
    "ar_MA" ) OS_LANG_ID=6145;;
    "ar_OM" ) OS_LANG_ID=8193;;
    "ar_QA" ) OS_LANG_ID=16385;;
    "ar_SA" ) OS_LANG_ID=1025;;
    "ar_SY" ) OS_LANG_ID=10241;;
    "ar_TN" ) OS_LANG_ID=7169;;
    "ar_AE" ) OS_LANG_ID=14337;;
    "ar_YE" ) OS_LANG_ID=9217;;
    "hy_AM" ) OS_LANG_ID=1067;;
    "az_AZ" ) OS_LANG_ID=2092;;
    "eu_ES" ) OS_LANG_ID=1069;;
    "be_BY" ) OS_LANG_ID=1059;;
    "bn_IN" ) OS_LANG_ID=1093;;
    "bs_BA" ) OS_LANG_ID=5146;;
    "ca_ES" ) OS_LANG_ID=1027;;
    "zh_HK" ) OS_LANG_ID=3076;;
    "zh_MO" ) OS_LANG_ID=5124;;
    "zh_SG" ) OS_LANG_ID=4100;;
    "zh_TW" ) OS_LANG_ID=1028;;
    "hr_BA" ) OS_LANG_ID=4122;;
    "hr_HR" ) OS_LANG_ID=1050;;
    "da_DK" ) OS_LANG_ID=1030;;
    "dv_MV" ) OS_LANG_ID=1125;;
    "nl_BE" ) OS_LANG_ID=2067;;
    "en_AU" ) OS_LANG_ID=3081;;
    "en_BZ" ) OS_LANG_ID=10249;;
    "en_CA" ) OS_LANG_ID=4105;;
    "en_IE" ) OS_LANG_ID=6153;;
    "en_JM" ) OS_LANG_ID=8201;;
    "en_NZ" ) OS_LANG_ID=5129;;
    "en_PH" ) OS_LANG_ID=13321;;
    "en_ZA" ) OS_LANG_ID=7177;;
    "en_TT" ) OS_LANG_ID=11273;;
    "en_GB" ) OS_LANG_ID=2057;;
    "en_ZW" ) OS_LANG_ID=12297;;
    "mk_MK" ) OS_LANG_ID=1071;;
    "fo_FO" ) OS_LANG_ID=1080;;
    "fa_IR" ) OS_LANG_ID=1065;;
    "fil_PH" ) OS_LANG_ID=1124;;
    "fi_FI" ) OS_LANG_ID=1035;;
    "fr_BE" ) OS_LANG_ID=2060;;
    "fr_CA" ) OS_LANG_ID=3084;;
    "fr_LU" ) OS_LANG_ID=5132;;
    "fr_MC" ) OS_LANG_ID=6156;;
    "fr_CH" ) OS_LANG_ID=4108;;
    "gl_ES" ) OS_LANG_ID=1110;;
    "ka_GE" ) OS_LANG_ID=1079;;
    "de_AT" ) OS_LANG_ID=3079;;
    "de_LI" ) OS_LANG_ID=5127;;
    "de_LU" ) OS_LANG_ID=4103;;
    "de_CH" ) OS_LANG_ID=2055;;
    "el_GR" ) OS_LANG_ID=1032;;
    "gu_IN" ) OS_LANG_ID=1095;;
    "he_IL" ) OS_LANG_ID=1037;;
    "hi_IN" ) OS_LANG_ID=1081;;
    "is_IS" ) OS_LANG_ID=1039;;
    "id_ID" ) OS_LANG_ID=1057;;
    "iu_CA" ) OS_LANG_ID=1117;;
    "ga_IE" ) OS_LANG_ID=2108;;
    "it_CH" ) OS_LANG_ID=2064;;
    "ja_JP" ) OS_LANG_ID=1041;;
    "kn_IN" ) OS_LANG_ID=1099;;
    "kk_KZ" ) OS_LANG_ID=1087;;
    "kok_IN" ) OS_LANG_ID=1111;;
    "ko_KR" ) OS_LANG_ID=1042;;
    "ky_KG" ) OS_LANG_ID=1088;;
    "lv_LV" ) OS_LANG_ID=1062;;
    "lt_LT" ) OS_LANG_ID=1063;;
    "ms_BN" ) OS_LANG_ID=2110;;
    "ms_MY" ) OS_LANG_ID=1086;;
    "ml_IN" ) OS_LANG_ID=1110;;
    "mt_MT" ) OS_LANG_ID=1082;;
    "mi_NZ" ) OS_LANG_ID=1153;;
    "mr_IN" ) OS_LANG_ID=1102;;
    "mn_MN" ) OS_LANG_ID=2128;;
    "ne_NP" ) OS_LANG_ID=1121;;
    "nb_NO" ) OS_LANG_ID=1044;;
    "nn_NO" ) OS_LANG_ID=2068;;
    "ps_AF" ) OS_LANG_ID=1123;;
    "pa_IN" ) OS_LANG_ID=1094;;
    "qu_BO" ) OS_LANG_ID=1131;;
    "qu_EC" ) OS_LANG_ID=2155;;
    "qu_PE" ) OS_LANG_ID=3179;;
    "ro_RO" ) OS_LANG_ID=1048;;
    "sa_IN" ) OS_LANG_ID=1103;;
    "sr_BA" ) OS_LANG_ID=3098;;
    "sl_SI" ) OS_LANG_ID=1060;;
    "es_AR" ) OS_LANG_ID=11274;;
    "es_BO" ) OS_LANG_ID=16394;;
    "es_CL" ) OS_LANG_ID=13322;;
    "es_CO" ) OS_LANG_ID=9226;;
    "es_CR" ) OS_LANG_ID=5130;;
    "es_DO" ) OS_LANG_ID=7178;;
    "es_EC" ) OS_LANG_ID=12298;;
    "es_SV" ) OS_LANG_ID=17418;;
    "es_GT" ) OS_LANG_ID=4106;;
    "es_HN" ) OS_LANG_ID=18442;;
    "es_MX" ) OS_LANG_ID=2058;;
    "es_NI" ) OS_LANG_ID=19466;;
    "es_PA" ) OS_LANG_ID=6154;;
    "es_PY" ) OS_LANG_ID=15370;;
    "es_PE" ) OS_LANG_ID=10250;;
    "es_PR" ) OS_LANG_ID=20490;;
    "es_UY" ) OS_LANG_ID=14346;;
    "es_VE" ) OS_LANG_ID=8202;;
    "sw_KE" ) OS_LANG_ID=1089;;
    "sv_FI" ) OS_LANG_ID=2077;;
    "ta_IN" ) OS_LANG_ID=1097;;
    "tt_RU" ) OS_LANG_ID=1092;;
    "te_IN" ) OS_LANG_ID=1098;;
    "th_TH" ) OS_LANG_ID=1054;;
    "ur_PK" ) OS_LANG_ID=1056;;
    "uz_UZ" ) OS_LANG_ID=2115;;
    "vi_VN" ) OS_LANG_ID=1066;;
    "cy_GB" ) OS_LANG_ID=1106;;
    "xh_ZA" ) OS_LANG_ID=1076;;
    "zu_ZA" ) OS_LANG_ID=1077;;
    * ) OS_LANG_ID=1033;;
esac

APP_LANG[0]="Arabic, Saudi Arabia"
APP_LANG[1]="Bulgarian, Bulgaria"
APP_LANG[2]="Chinese, People's Republic of China"
APP_LANG[3]="Chinese, Taiwan"
APP_LANG[4]="Croatian, Croatia"
APP_LANG[5]="Czech, Czech Republic"
APP_LANG[6]="Dutch, Netherlands"
APP_LANG[7]="English, United States"
APP_LANG[8]="Estonian, Estonia"
APP_LANG[9]="French, France"
APP_LANG[10]="German, Germany"
APP_LANG[11]="Greek, Greece"
APP_LANG[12]="Hungarian, Hungary"
APP_LANG[13]="Italian, Italy"
APP_LANG[14]="Polish, Poland"
APP_LANG[15]="Portuguese, Brazil"
#APP_LANG[12]="Portuguese, Portugal"
APP_LANG[16]="Russian, Russia"
APP_LANG[17]="Serbian, Serbia and Montenegro"
APP_LANG[18]="Slovak, Slovakia"
APP_LANG[19]="Spanish, Spain"
APP_LANG[20]="Swedish, Sweden"
APP_LANG[21]="Turkish, Turkey"
APP_LANG[22]="Ukrainian, Ukraine"

echo
i=0
while [ $i -le 22 ]; do
    echo "$((i+1)). ${APP_LANG[i]}"
    i=$((i+1))
done

APP_LANG_INDEX=5
while true; do
    echo -n "Please select the language[number,default:8]: "
    read NUMBER
    if [ -z "$NUMBER" ] ; then 
       APP_LANG_INDEX=7
       break;
    fi
    if [ ! -z $(echo $NUMBER | sed -e 's/[0-9]//g') ] || [ $NUMBER -lt 1 ] || [ $NUMBER -gt 23 ]; then
        continue
    else
        APP_LANG_INDEX=$((NUMBER-1))
        break
    fi
done

APP_LANG_ID=1033
case $APP_LANG_INDEX in
    "0" )
	APP_LANG_ID=1025
	CMD_LANG="Arabic - By Community"
	;;
    "1" )
	APP_LANG_ID=1026
	CMD_LANG="Bulgarian - By Community"
	;;
    "2" )
	APP_LANG_ID=2052
	CMD_LANG="Chinese Simplified - By COMODO"
	;;
    "3" )
	APP_LANG_ID=1028
	CMD_LANG="Chinese Traditional - By COMODO"
	;;
    "4" )
	APP_LANG_ID=1050
	CMD_LANG="Croatian - By Community"
	;;
    "5" )
	APP_LANG_ID=1029
	CMD_LANG="Czech - By Community"
	;;
    "6" )
	APP_LANG_ID=1043
	CMD_LANG="Dutch - By Community"
	;;
    "7" )
	APP_LANG_ID=1033
	CMD_LANG="English(United States) - Default"
	;;
    "8" )
	APP_LANG_ID=1061
	CMD_LANG="Estonian - By Community"
	;;
    "9" )
	APP_LANG_ID=1036
	CMD_LANG="French - By Community"
	;;
    "10" )
	APP_LANG_ID=1031
	CMD_LANG="Germany - By Community"
	;;
    "11" )
	APP_LANG_ID=1032
	CMD_LANG="Greek - By Community"
	;;
    "12" )
	APP_LANG_ID=1038
	CMD_LANG="Hungarian - By Community"
	;;
    "13" )
	APP_LANG_ID=1040
	CMD_LANG="Itanian - By Community"
	;;
#    "12" ) APP_LANG_ID=2070;;
    "14" )
	APP_LANG_ID=1045
	CMD_LANG="Polish - By Community"
	;;
    "15" )
	APP_LANG_ID=1046
	CMD_LANG="Brasil - By Community"
	;;
    "16" )
	APP_LANG_ID=1049
	CMD_LANG="Russian - By COMODO"
	;;
    "17" )
	APP_LANG_ID=1060
	CMD_LANG="Serbian - By Community"
	;;
    "18" )
	APP_LANG_ID=1051
	CMD_LANG="Slovak - By Community"
	;;
    "19" )
	APP_LANG_ID=1034
	CMD_LANG="Spanish - By Community"
	;;
    "20" )
	APP_LANG_ID=1053
	CMD_LANG="Swedish - By Community"
	;;
    "21" )
	APP_LANG_ID=1055
	CMD_LANG="Turkish - By COMODO"
	;;
    "22" )
	APP_LANG_ID=1058
	CMD_LANG="Ukrainian - By Community"
	;;
    * )
	APP_LANG_ID=1033
	CMD_LANG="English(United States) - Default"
	;;
esac

OSES="Ubuntu Debian Redhat Fedora openSUSE SUSE CentOS FreeBSD Mint"
OS_NAME="Unknown"
for T in $OSES; do
    if cat /etc/issue | grep $T > /dev/null 2>&1; then
        OS_NAME=$T
        break
    fi
done

OS_ID=23
case $OS_NAME in
    "Ubuntu" ) OS_ID=15;;
    "Debian" ) OS_ID=16;;
    "Redhat" ) OS_ID=17;;
    "Fedora" ) OS_ID=18;;
    "openSUSE" ) OS_ID=20;;
    "SUSE" ) OS_ID=19;;
    "CentOS" ) OS_ID=21;;
    "FreeBSD" ) OS_ID=22;;
    "Mint" ) OS_ID=23;;
    * ) OS_ID=24;;
esac

if [ "$(uname -m)" == "x86_64" ]; then
    OS_PLAT=64
else
    OS_PLAT=32
fi

echo -e "\n\033[1mBuild the RedirFS kernel modules for real-time protection...\033[0m\n"

if ! test -d /lib/modules/`uname -r`/build; then
    echo -e "\nThen linux kernel source or linux kernel headers for your current kernel version $(uname -r) can not be found."
    echo -e "Please install the kernel source or kernel headers for $(uname -r), then run this script again."
fi

test -d /tmp/driver && rm -rf /tmp/driver
tar xf /opt/COMODO/driver.tar -C /tmp
cd /tmp/driver
ROOT_PATH=/tmp/driver make all
ROOT_PATH=/tmp/driver make install
/sbin/depmod -a

if /sbin/modprobe redirfs && /sbin/modprobe avflt; then
    echo -e "\nRedirFS kernel modules have been successfully installed.\n"
else
    echo -e "\nRedirFS kernel modules installation failed.\n"
fi

sed -i "s/\(   <LanguageName>\)\(.*\)\(<\/LanguageName>\)/\1${CMD_LANG}\3/" /opt/COMODO/etc/COMODO.xml
sh /opt/COMODO/load_cmdagent.sh restart
sh /opt/COMODO/load_cmgdaemon.sh restart

rm -rf /tmp/driver

if [ -e /usr/bin/wget ]; then
wget -q -o /dev/null -O /dev/null http://licensing.security.comodo.com/info\?comp=${COMPUTER_ID}\&product=31\&affiliate=\&version=${PRODUCT_VERSION}\&activitytype=2\&key=\&email=${EMAIL}\&oslang=${OS_LANG_ID}\&applang=${APP_LANG_ID}\&osid=${OS_ID}\&osplat=${OS_PLAT}\&feedback= > /dev/null 2>&1 &
elif [ -e /usr/bin/curl ]; then
curl http://licensing.security.comodo.com/info\?comp=${COMPUTER_ID}\&product=31\&affiliate=\&version=${PRODUCT_VERSION}\&activitytype=2\&key=\&email=${EMAIL}\&oslang=${OS_LANG_ID}\&applang=${APP_LANG_ID}\&osid=${OS_ID}\&osplat=${OS_PLAT}\&feedback= > /dev/null 2>&1 &
fi
    
echo -e "\n\033[1mCOMODO Antivirus is successfully configured, you can start it from Menu or Desktop.\033[0m\n"

